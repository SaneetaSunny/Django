from django.apps import AppConfig


class AttappConfig(AppConfig):
    name = 'attapp'
